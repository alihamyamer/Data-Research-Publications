Labour share in year 2000 (benchmark)

Goal: benchmark model for changing labour share in year 2000

Folder: shares_2000

File change:  fixed_params.txt

Code change : No change 
