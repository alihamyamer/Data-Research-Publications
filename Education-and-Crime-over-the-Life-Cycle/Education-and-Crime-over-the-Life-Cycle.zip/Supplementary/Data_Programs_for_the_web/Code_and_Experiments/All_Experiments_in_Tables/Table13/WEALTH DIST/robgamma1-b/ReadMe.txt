Lower average intervivos (benchmark)

Goal: benchmark model for lower gamma 1

Folder: robgamma1-b

File change:  fixed_params.txt

Code change : No change 
