Lower average intervivos (GE)

Goal: General equilibrium for lower gamma 1

Folder: robgamma1-b-subGE

File change:  fixed_params.txt

Code change : No change 

