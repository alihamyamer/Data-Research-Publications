Higher average intervivos (GE)

Goal: General equilibrium for higher gamma 1

Folder: robgamma1-a-subGE

File change:  fixed_params.txt

Code change : No change 
