Lower % zero initial wealth (GE)

Goal: General equilibrium for lower gamma 2

Folder: robgamma2-b-subGE

File change:  fixed_params.txt

Code change : No change 
