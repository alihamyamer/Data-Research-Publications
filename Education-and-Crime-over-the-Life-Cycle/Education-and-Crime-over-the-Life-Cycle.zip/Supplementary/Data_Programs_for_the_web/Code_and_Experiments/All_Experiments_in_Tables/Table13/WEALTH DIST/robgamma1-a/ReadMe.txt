Higher average intervivos (benchmark)

Goal: benchmark model for higher gamma 1

Folder: robgamma1-a

File change:  fixed_params.txt

Code change : No change 
