Higher % zero initial wealth (benchmark)

Goal: benchmark model for higher gamma 2

Folder: robgamma2-a

File change:  fixed_params.txt

Code change : No change
