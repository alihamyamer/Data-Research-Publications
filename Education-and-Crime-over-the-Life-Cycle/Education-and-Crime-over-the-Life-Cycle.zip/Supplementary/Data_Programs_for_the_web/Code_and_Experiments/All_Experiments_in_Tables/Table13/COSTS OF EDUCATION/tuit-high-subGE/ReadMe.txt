Higher cost of college (GE)

Goal: general equlibrium for increasing college tuition by 50%

Folder: tuit-high-subGE

File change:  fixed_params.txt

Code change : see �simul.f90� TUIT (2) = MAX(0.147d0  * UNCavgearn , 0.0D0)

