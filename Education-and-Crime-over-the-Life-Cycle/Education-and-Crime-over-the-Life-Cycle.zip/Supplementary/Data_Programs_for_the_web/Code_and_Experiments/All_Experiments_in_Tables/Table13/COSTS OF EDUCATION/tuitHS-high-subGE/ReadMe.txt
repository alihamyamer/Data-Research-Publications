Higher cost of High School (GE)

Goal: benchmark model for double high school tuition

Folder: tuitHS-high-subGE

File change:  fixed_params.txt

Code change : see �simul.f90� TUIT (1) = MAX(0.020d0 * UNCavgearn , 0.0D0)
