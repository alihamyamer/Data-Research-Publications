Higher cost of college (benchmark)

Goal: benchmark model for increasing college tuition by 50%

Folder: tuit-high

File change:  fixed_params.txt

Code change : see �simul.f90� TUIT (2) = MAX(0.147d0  * UNCavgearn , 0.0D0)

