Lower cost of college (GE)

Goal: general equilibrium for decreasing college tuition by 50%

Folder: tuit-low-subGE

File change:  fixed_params.txt

Code change : see �simul.f90� TUIT (2) = MAX(0.047d0  * UNCavgearn , 0.0D0)

